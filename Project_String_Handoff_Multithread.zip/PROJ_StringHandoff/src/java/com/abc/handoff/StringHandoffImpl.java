package com.abc.handoff;

import com.abc.pp.stringhandoff.*;
import com.programix.thread.*;

/**
 * StringHandoff is used to pass a String from one thread to another. The passer
 * and the receiver meet inside an instance for the handoff. For example, if
 * pass() is called and there is not receiver waiting, the thread calling pass()
 * will block until the receiver arrives. Similarly, if receive() is called and
 * there is no passer waiting, the thread calling receive() will block until the
 * passer arrives.
 * 
 * @author Abrar Zawed 
 * Date Created: 15th April, 2019 
 * Final Modification: 29th April, 2019
 */

public class StringHandoffImpl implements StringHandoff {

	// Signals ON and OFF status of flag
	enum Flag {
		ON, OFF
	}

	// Instance variables
	private String message;
	private String receivedMessage;
	private Flag passFlag;
	private Flag receiveFlag;
	private boolean shutdown;

	/**
	 * Constructor that initiates StringHandoffImpl
	 */
	public StringHandoffImpl() {
		message = null;
		receivedMessage = null;
		receiveFlag = Flag.OFF;
		passFlag = Flag.OFF;
		shutdown = false;
	}

	/**
	 * Passes a String at a rendezvous
	 * 
	 * @param msg       - message to be passed
	 * @param msTimeout - number of millisecond until it throws a timeout
	 * @return void
	 */
	@Override
	public synchronized void pass(String msg, long msTimeout)
			throws InterruptedException, TimedOutException, ShutdownException, IllegalStateException {
		if (passFlag == Flag.ON) {
			if (shutdown == true) {
				throw new ShutdownException("Shutdown Exception occurredured");
			}
			throw new IllegalStateException("Illegal State Exception. Another thread is already waiting to pass.");
		}

		try {
			// turn the flag on
			passFlag = Flag.ON;

			if (shutdown == true) { // if shutdown happens while idle
				throw new ShutdownException("Shutdown Exception occurred");
			}

			// if no other thread is waiting to pass, current thread can go ahead
			if (message == null) {
				message = msg;
				notifyAll();
			}

			// Wait without any timeout
			if (msTimeout == 0L) {
				while (message != null) {
					wait();
					if (shutdown == true) {
						throw new ShutdownException("Shutdown Exception occurred while waiting for without timeout");
					}
				}
				message = msg;
				notifyAll();
			}

			else {
				// Wait with a adjusting timeout
				long msEndTime = System.currentTimeMillis() + msTimeout;
				long msRemaining = msTimeout;

				while (msRemaining > 0L && message != null) {
					wait(msRemaining);
					if (shutdown == true) {
						throw new ShutdownException("Shutdown Exception occurred while another thread is waiting to pass");
					}
					msRemaining = msEndTime - System.currentTimeMillis();
				}

				if (message == null) {
					message = msg;
					notifyAll();
				} else {
					throw new TimedOutException("Timed Out"); // timed out
				}
			}
		} catch (InterruptedException e) {
			// Indicates of leaving gracefully
		} finally {
			message = null;
			passFlag = Flag.OFF;
		}
	}

	/**
	 * Passes a String at a rendezvous without any timeout 
	 * @param msg - message to be passed
	 * @return void
	 */
	@Override
	public synchronized void pass(String msg) throws InterruptedException, ShutdownException, IllegalStateException {
		pass(msg, 0);
	}

	/**
	 * Receives a String at a rendezvous
	 * @param msTimeout - number of millisecond until it throws a timeout
	 * @return passed String
	 */
	@Override
	public synchronized String receive(long msTimeout)
			throws InterruptedException, TimedOutException, ShutdownException, IllegalStateException {

		if (receiveFlag == Flag.ON) {
			if (shutdown == true) {
				throw new ShutdownException("Shutdown Exception occurred");
			}
			throw new IllegalStateException("Illegal State Exception. Another thread is already waiting to pass");
		}

		try {
			receiveFlag = Flag.ON;

			if (shutdown == true) { // if shutdown happens while idle
				throw new ShutdownException("Shutdown Exception occurred while idle");
			}

			// if no other thread is waiting to receive, current thread can go ahead and receive
			if (message != null) {
				receivedMessage = message;
				message = null;
				receiveFlag = Flag.OFF;
				notifyAll();
				return receivedMessage;
			}

			// waiting without timeout
			if (msTimeout == 0L) {
				while (message == null) {
					wait();
					if (shutdown == true) {
						throw new ShutdownException();
					}
				}
				receivedMessage = message;
				message = null;
				receiveFlag = Flag.OFF;
				notifyAll();
				return receivedMessage;
			}

			// adjust timeout
			long msEndTime = System.currentTimeMillis() + msTimeout;
			long msRemaining = msTimeout;

			while (msRemaining > 0L && message == null) {
				wait(msRemaining);

				if (shutdown == true) {
					throw new ShutdownException("Shutdown Exception occurred");
				}
				msRemaining = msEndTime - System.currentTimeMillis();
			}

			if (message != null) {
				receivedMessage = message;
				message = null;
				receiveFlag = Flag.OFF;
				notifyAll();
				return receivedMessage;
			} else {
				throw new TimedOutException();
			}
		} finally {
			message = null;
			receiveFlag = Flag.OFF;
		}
	}

	/**
	 * Receives a String at a rendezvous
	 * @return passed String
	 */
	@Override
	public synchronized String receive() throws InterruptedException, ShutdownException, IllegalStateException {
		return receive(0);
	}

	/**
	 * Method that calls shutdown
	 */
	@Override
	public synchronized void shutdown() {
		shutdown = true;
		notifyAll();
	}

	/**
	 * Method that returns the lock object
	 */
	@Override
	public Object getLockObject() {
		return this;
	}
}